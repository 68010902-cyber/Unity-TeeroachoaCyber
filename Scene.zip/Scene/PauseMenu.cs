using UnityEngine;
using UnityEngine.SceneManagement;

public class PauseMenu : MonoBehaviour
{
    public void QuitToLogin()
    {
        SceneManager.LoadScene("LogINScene");
    }
}